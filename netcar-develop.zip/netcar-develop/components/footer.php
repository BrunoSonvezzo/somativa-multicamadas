<div class="bg-white shadow fixed bottom-0 w-100">
  <div class="container">
    <div class="row p-2">
      <!-- <div class="col-6 col-md-2 col-sm-12">
        <h5>Section</h5>
        <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Home</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Features</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Pricing</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">FAQs</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Sobw</a></li>
        </ul>
      </div>     -->

      <div class="col-12 flex justify-content-center ">
        <?php require 'loader.php' ?>
      </div>    
    </div>

    <div class="flex justify-content-center mb-2 py-2 border-top">
      <p>&copy; 2023 NETCAR. Todos os direitos reservados.</p>
    </div>

  </div>
</div>